# SNACS_FA2

Code and layout for SNACS course paper

experiment.py: Experiment codes (written in Python)

Visual file: Visual layout graphs

forceatlas2.py: Forceatlas2 algorithm library 
